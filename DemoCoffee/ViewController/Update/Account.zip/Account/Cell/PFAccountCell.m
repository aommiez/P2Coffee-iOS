//
//  PFAccountCell.m
//  DemoCoffee
//
//  Created by Pariwat on 6/27/14.
//  Copyright (c) 2014 Platwo fusion. All rights reserved.
//

#import "PFAccountCell.h"

@implementation PFAccountCell

- (void)awakeFromNib
{
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
