//
//  PFAccountCell.h
//  DemoCoffee
//
//  Created by Pariwat on 6/27/14.
//  Copyright (c) 2014 Platwo fusion. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PFAccountCell : UITableViewCell

@property (strong, nonatomic) IBOutlet UIView *bgView;
@property (weak, nonatomic) IBOutlet UIImageView *imgrow;
@property (weak, nonatomic) IBOutlet UITextField *detailrow;

@end
